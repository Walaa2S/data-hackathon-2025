'use client';

import MarketHeader from "@/components/market/market-header";
import MarketTable from "@/components/market/market-table";
import { marketData } from "@/lib/sample-data";

export default function MarketPage() {
  return (
    <div className="container px-4 py-8 md:py-12">
      <MarketHeader />
      <MarketTable data={marketData} />
    </div>
  );
}
