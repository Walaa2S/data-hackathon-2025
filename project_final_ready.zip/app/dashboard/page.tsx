'use client';

import DashboardHeader from "@/components/dashboard/dashboard-header";
import ChartSection from "@/components/dashboard/chart-section";
import CSVUploadSection from "@/components/dashboard/csv-upload-section";
import { lineChartData, barChartData, pieChartData } from "@/lib/sample-data";

export default function DashboardPage() {
  return (
    <div className="container px-4 py-8 md:py-12">
      <DashboardHeader />
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <ChartSection 
          title="Monthly Revenue"
          type="line"
          data={lineChartData}
        />
        <ChartSection 
          title="Category Distribution"
          type="bar"
          data={barChartData}
        />
        <ChartSection 
          title="Market Share"
          type="pie"
          data={pieChartData}
        />
      </div>
      
      <CSVUploadSection />
    </div>
  );
}