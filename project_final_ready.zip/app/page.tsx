'use client';

import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  ChevronRight,
  BarChart3,
  LineChart,
  Upload,
  PieChart
} from "lucide-react";
import HeroSection from "@/components/hero-section";
import FeatureCard from "@/components/feature-card";
import ServerActionDemo from "./components/server-action-demo";

export default function HomePage() {
  return (
    <div className="relative">
      <HeroSection />

      <section className="container px-4 py-16 md:py-24">
        <div className="mx-auto mb-12 max-w-3xl text-center">
          <h2 className="mb-4 text-3xl font-bold md:text-4xl">Powerful Features</h2>
          <p className="text-muted-foreground">
            Unlock insights from your data with our comprehensive set of tools and features.
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <FeatureCard 
            icon={<Upload />}
            title="CSV Upload"
            description="Easily upload and parse CSV files with drag and drop functionality."
          />
          <FeatureCard 
            icon={<BarChart3 />}
            title="Market Analysis"
            description="View real-time market data and identify trends with interactive charts."
          />
          <FeatureCard 
            icon={<LineChart />}
            title="Custom Dashboards"
            description="Create personalized dashboards to monitor your key metrics."
          />
          <FeatureCard 
            icon={<PieChart />}
            title="Data Visualization"
            description="Transform raw data into beautiful, insightful visualizations."
          />
          <FeatureCard 
            icon={<ChevronRight />}
            title="Real-time Updates"
            description="Get instant updates as your data changes over time."
          />
        </div>
      </section>

      <section className="container px-4 py-16">
        <ServerActionDemo />
      </section>

      <section className="bg-muted py-16 md:py-24">
        <div className="container px-4">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-4 text-3xl font-bold md:text-4xl">Get Started Today</h2>
            <p className="mb-8 text-muted-foreground">
              Take your data analysis to the next level with our powerful tools.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button asChild size="lg">
                <Link href="/dashboard">Explore Dashboard</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/market">View Market Data</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
