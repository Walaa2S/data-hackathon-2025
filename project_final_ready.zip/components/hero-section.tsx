"use client";

import Link from "next/link";
import {
  ArrowRight,
  BarChart3,
  PieChart,
  Database,
  LineChart,
  Cloud,
  AreaChart,
  FileBarChart,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Typewriter } from "react-simple-typewriter";

export default function HeroSection() {
  const topRowIcons = [BarChart3, PieChart, Database, LineChart, Cloud];
  const bottomRowIcons = [ AreaChart, FileBarChart, PieChart, LineChart, Cloud];

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0f172a] to-[#1e293b] px-4 overflow-hidden">
      {/* ✅ خلفية الأيقونات المتحركة */}
      <div className="absolute top-0 left-0 right-0 px-4 z-0 pointer-events-none">
        {/* الصف العلوي */}
        <div className="flex justify-between mb-100">
          {topRowIcons.map((Icon, idx) => (
            <motion.div
              key={`top-${idx}`}
              className="text-white/15"
              animate={{ y: [0, 8, 0] }}
              transition={{
                duration: 5 + (idx % 3),
                delay: idx * 0.2,
                repeat: Infinity,
                ease: "easeInOut",

              }}
            >
              <Icon className="w-5 h-5 md:w-6 md:h-6" />
            </motion.div>
          ))}
        </div>

        {/* الصف السفلي بشكل عشوائي مرتب */}
        <div className="relative h-10 w-full mt-10">
          {bottomRowIcons.map((Icon, idx) => (
            <motion.div
              key={`bottom-${idx}`}
              className="absolute text-white/15"
              style={{
                left: `${18 + idx * 15 + Math.random() * 5}%`,
                top: `${idx % 2 === 0 ? "0px" : "50px"}`,
              }}
              animate={{ y: [0, 8, 0] }}
              transition={{
                duration: 6 + (idx % 4),
                delay: idx * 0.25,
                repeat: Infinity,
                ease: "easeInOut",
                
              }}
            >
              <Icon className="w-5 h-5 md:w-6 md:h-6" />
            </motion.div>
          ))}
        </div>
      </div>

      {/* ✅ المحتوى */}
      <div className="relative z-10 text-center max-w-2xl">
        <motion.h1
          className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 leading-tight"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          Transform Your{" "}
          <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            Data
          </span>{" "}
          Into{" "}
          <span className="text-blue-300">
            <Typewriter
              words={["Insights", "Trends", "Strategies", "Visuals"]}
              loop
              cursor
              cursorStyle="_"
              typeSpeed={90}
              deleteSpeed={50}
              delaySpeed={1500}
            />
          </span>
        </motion.h1>

        <motion.p
          className="text-lg text-slate-300 mb-10"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          Upload, analyze, and visualize your data with our powerful and intuitive platform.
        </motion.p>

        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Button asChild size="lg" className="gap-2">
            <Link href="/dashboard">
              Get Started <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link href="/market">Explore Market</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
