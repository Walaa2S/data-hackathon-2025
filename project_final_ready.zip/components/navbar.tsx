'use client';

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BarChart3, Home, LineChart, BarChart, Moon, Sun } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";

const routes = [
  { name: "Home", path: "/", icon: Home },
  { name: "Market", path: "/market", icon: BarChart3 },
  { name: "Dashboard", path: "/dashboard", icon: LineChart },
];

export default function Navbar() {
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();

  return (
    <header className="fixed top-0 z-50 w-full bg-background/40 backdrop-blur-md">
      {/* ✅ شريط التنقل */}  
      <div className="max-w-7xl mx-auto h-16 px-4 flex items-center justify-between">

        {/* يسار: الشعار */}
        <div className="flex-shrink-0">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg">
            <BarChart className="h-5 w-5" />
            <span>DataInsight</span>
          </Link>
        </div>

        {/* وسط: روابط التنقل */}
        <nav className="hidden md:flex gap-6 text-sm font-medium justify-center">
          {routes.map((route) => (
            <Link
              key={route.path}
              href={route.path}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-md transition-colors",
                pathname === route.path
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-primary hover:bg-muted"
              )}
            >
              <route.icon className="h-4 w-4" />
              {route.name}
            </Link>
          ))}
        </nav>

        {/* يمين: زر الوضع الداكن */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>
        </div>

      </div>
    </header>
  );
}
