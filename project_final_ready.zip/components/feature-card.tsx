"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { motion } from "framer-motion";

interface FeatureCardProps {
  icon: React.ReactNode; // ✅ هذا هو التعديل
  title: string;
  description: string;
  link?: string;
}

export default function FeatureCard({
  icon,
  title,
  description,
  link
}: FeatureCardProps) {
  return (
    <motion.div
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      className="group"
    >
      <Card className="h-full transition-shadow duration-300 hover:shadow-md">
        <CardHeader>
          <div className="mb-2 rounded-md bg-primary/10 p-2 w-fit">
            {icon}
          </div>
          <CardTitle className="text-xl">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription>{description}</CardDescription>
        </CardContent>
        {link && (
          <CardFooter>
            <Button
              variant="ghost"
              size="sm"
              asChild
              className="group-hover:translate-x-1 transition-transform duration-300"
            >
              <Link href={link}>
                Learn more <ChevronRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        )}
      </Card>
    </motion.div>
  );
}
