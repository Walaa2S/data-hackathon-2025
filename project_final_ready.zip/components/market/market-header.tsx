"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, ArrowUpDown, TrendingUp, TrendingDown } from "lucide-react";
import { motion } from "framer-motion";

export default function MarketHeader() {
  return (
    <div className="mb-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="mb-2 text-3xl font-bold tracking-tight">Market</h1>
        <p className="mb-6 text-muted-foreground">
          View and analyze real-time market data.
        </p>
      </motion.div>

      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <StatCard 
          title="Market Cap"
          value="$2.4T"
          change={1.2}
          isPositive={true}
          delay={0.1}
        />
        <StatCard 
          title="24h Volume"
          value="$86.5B"
          change={-2.5}
          isPositive={false}
          delay={0.2}
        />
        <StatCard 
          title="BTC Dominance"
          value="43.8%"
          change={0.5}
          isPositive={true}
          delay={0.3}
        />
        <StatCard 
          title="Active Markets"
          value="13,942"
          change={3.7}
          isPositive={true}
          delay={0.4}
        />
      </div>

      <div className="mb-8 flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search markets..." className="pl-9" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <ArrowUpDown className="h-4 w-4" />
            Sort
          </Button>
          <Button variant="outline">Filter</Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-6">
        <TabsList>
          <TabsTrigger value="all">All Assets</TabsTrigger>
          <TabsTrigger value="gainers">Top Gainers</TabsTrigger>
          <TabsTrigger value="losers">Top Losers</TabsTrigger>
          <TabsTrigger value="volume">Highest Volume</TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  change: number;
  isPositive: boolean;
  delay?: number;
}

function StatCard({ title, value, change, isPositive, delay = 0 }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
    >
      <Card>
        <CardContent className="flex items-center justify-between p-6">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
          </div>
          <div className={`flex items-center gap-1 rounded-full ${isPositive ? 'text-green-500' : 'text-red-500'} text-sm font-medium`}>
            {isPositive ? (
              <TrendingUp className="h-4 w-4" />
            ) : (
              <TrendingDown className="h-4 w-4" />
            )}
            <span>{change}%</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}